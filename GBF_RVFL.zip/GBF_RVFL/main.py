import os
import numpy as np
from RVFL import RVFL_train
from gen_ball import gen_balls, ball_membership
from sklearn.model_selection import KFold

directory = './'
file_list = os.listdir(directory)

for file_name in file_list:
    if file_name.endswith(".csv"):
        file_path = os.path.join(directory, file_name)
        print(directory)
        print(file_name)
        file_data = np.loadtxt(file_path, delimiter=',')
        
        m, n = file_data.shape
        for i in range(m):
            if file_data[i, n-1] == 0:
                file_data[i, n-1] = -1
    
        np.random.seed(0)
        indices = np.random.permutation(m)
        file_data = file_data[indices]
        A_train=file_data[0:int(m*(1-0.30))]
        A_test=file_data[int(m * (1-0.30)):]
        #A, B = GanBall_main(AA_train)
        #A_train = np.vstack((A, B))
    
        m, n = A_train.shape
        indices = np.random.permutation(m)
        A_train = A_train[indices]

        x1 = A_train[:, 0:n-1]
        y1 = A_train[:, n-1]
        xtest0 = A_test[:,0:n-1]
        ytest0 = A_test[:,n-1]
        # Normalize the data training and testing
        me = np.tile(np.mean(x1, axis=0), (x1.shape[0], 1))
        st = np.tile(np.std(x1, axis=0), (x1.shape[0], 1))
        tme = np.tile(np.mean(x1, axis=0), (xtest0.shape[0], 1))
        tst = np.tile(np.std(x1, axis=0), (xtest0.shape[0], 1))
        x1 = (x1 - me) / st
        xtest0 = (xtest0 - tme) / tst
       
        
        A_test = np.hstack((xtest0, ytest0.reshape(ytest0.shape[0], 1)))

        m1, n1 = A_test.shape
        for i in range(m1):
            if A_test[i, n1-1] == -1:
                A_test[i, n1-1] = 0
        
        AA_train = np.hstack((x1, y1.reshape(y1.shape[0], 1)))
          
        pur = 1 - (0.015 * 1)                      
        num = 1
        datab = gen_balls(AA_train, pur=pur, delbals=num)
        A_train = ball_membership(datab)
        
        Radius=[]
        for i in A_train:
            Radius.append(i[1])
        Center=[]
        for ii in A_train:
            Center.append(ii[0])
        Label=[]
        for iii in A_train:
            Label.append(iii[-1])
        Radius=np.array(Radius)

        score = []
        for iv in A_train:
            score.append(iv[-2])
        score=np.array(score)

        Center=np.array(Center)
        Label=np.array(Label)
        
        A_train=np.hstack((Center,score.reshape(-1, 1), Label.reshape(Label.shape[0], 1)))

        m, n = A_train.shape
        for i in range(m):
            if A_train[i, n-1] == -1:
                A_train[i, n-1] = 0

        c_1 = 0.1
        N = 23
        act = 6
        
        Eval, Test_time = RVFL_train(A_train, A_test, c_1, N,act, 1)

        Test_accuracy=Eval[0]
        print('Test Accuracy: %.4f' % Test_accuracy)